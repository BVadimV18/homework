public class Main {
    public static void main(String[] args) {
      char mychar = 'G';
      int myint = 89;
      byte mybyte = 4;
      short myshort = 56;
      float myfloat = 4.7333436F;
      double mydouble = 4.355453532;
      long mylong = 12121;




  System.out.println("345" + "->"+ "3;4;5;");

    }
}